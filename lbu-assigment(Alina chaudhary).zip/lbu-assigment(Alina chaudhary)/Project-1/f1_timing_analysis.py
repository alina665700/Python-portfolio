import sys
import os
from collections import defaultdict

# Parse driver details dynamically from a file
def load_driver_details(filename):
    """Load driver details from the given file."""
    driver_details = {}
    if not os.path.exists(filename):
        print(f"Warning: Driver details file '{filename}' not found. Using empty details.")
        return driver_details

    with open(filename, 'r') as file:
        for line in file:
            parts = line.strip().split(',')
            if len(parts) == 4:
                number, code, name, team = parts
                driver_details[code] = {
                    "name": name,
                    "team": team,
                    "number": int(number)
                }
    return driver_details

def parse_lap_time_file(filename):
    """Parse the lap time file and return race name and driver data."""
    if not os.path.exists(filename):
        raise FileNotFoundError(f"The file '{filename}' does not exist.")

    with open(filename, 'r') as file:
        lines = file.readlines()

    if not lines:
        raise ValueError("Lap time file is empty.")

    race_name = lines[0].strip()
    driver_data = defaultdict(list)

    for line in lines[1:]:
        code = line[:3].strip()
        try:
            time = float(line[3:].strip())
            driver_data[code].append(time)
        except ValueError:
            print(f"Skipping invalid lap time format in line: {line.strip()}")

    return race_name, driver_data

def calculate_statistics(driver_data):
    """Calculate statistics for each driver."""
    fastest_times = {}
    average_times = {}

    for driver, times in driver_data.items():
        if times:
            fastest_times[driver] = min(times)
            average_times[driver] = sum(times) / len(times)
        else:
            fastest_times[driver] = float('inf')
            average_times[driver] = float('inf')

    overall_fastest = min(fastest_times.items(), key=lambda x: x[1])
    overall_average = sum(t for times in driver_data.values() for t in times) / sum(len(times) for times in driver_data.values())

    return fastest_times, average_times, overall_fastest, overall_average

def display_results(race_name, driver_details, fastest_times, average_times, overall_fastest, overall_average):
    """Display results in a user-friendly format."""
    print(f"Race: {race_name}\n")
    
    overall_fastest_driver = overall_fastest[0]
    fastest_driver_details = driver_details.get(overall_fastest_driver, {})
    fastest_driver_name = fastest_driver_details.get("name", overall_fastest_driver)
    fastest_driver_team = fastest_driver_details.get("team", "Unknown Team")

    print(f"Fastest Driver: {fastest_driver_name} ({overall_fastest_driver}) with time {overall_fastest[1]:.3f} seconds\n")

    print("Fastest Lap Times (Ascending Order):")
    for driver, time in sorted(fastest_times.items(), key=lambda x: x[1]):
        details = driver_details.get(driver, {})
        name = details.get("name", driver)
        team = details.get("team", "Unknown Team")
        print(f"  {driver} ({name}, {team}): {time:.3f}")

    print("\nDriver Statistics:")
    for driver in fastest_times:
        details = driver_details.get(driver, {})
        name = details.get("name", driver)
        team = details.get("team", "Unknown Team")
        fastest_time = fastest_times[driver]
        average_time = average_times[driver]
        if fastest_time == float('inf'):
            print(f"  {driver} ({name}, {team}): No valid lap times")
        else:
            print(f"  {driver} ({name}, {team}): Fastest = {fastest_time:.3f}, Average = {average_time:.3f}")

    print(f"\nOverall Average Lap Time: {overall_average:.3f} seconds")

def main():
    if len(sys.argv) < 3:
        print("Usage: python f1_timing_analysis.py <lap_time_file> <driver_details_file>")
        sys.exit(1)

    lap_time_file = sys.argv[1]
    driver_details_file = sys.argv[2]

    try:
        driver_details = load_driver_details(driver_details_file)
        race_name, driver_data = parse_lap_time_file(lap_time_file)
        fastest_times, average_times, overall_fastest, overall_average = calculate_statistics(driver_data)
        display_results(race_name, driver_details, fastest_times, average_times, overall_fastest, overall_average)
    except FileNotFoundError as e:
        print(f"Error: {e}")
        sys.exit(1)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
