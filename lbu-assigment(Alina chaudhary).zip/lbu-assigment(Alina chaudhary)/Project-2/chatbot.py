import random
import json
import time

# Configuration for agent names and responses
AGENT_NAMES = ["Alex", "Jordan", "Taylor", "Morgan"]
KEYWORDS_RESPONSES = {
    "coffee": "The campus coffee bar is open from 8 AM to 8 PM every day.",
    "library": "The library is open 24/7 for students with a valid ID.",
    "admissions": "Admissions queries can be directed to admissions@poppleton.edu.",
    "sports": "The sports complex is open from 6 AM to 10 PM."
}
RANDOM_RESPONSES = [
    "That's interesting! Tell me more.",
    "I'm not sure about that. Can you ask something else?",
    "Hmm, let me think about that.",
    "I didn't quite get that. Could you clarify?"
]

# Generate a random agent name
agent_name = random.choice(AGENT_NAMES)

# Greet the user
def greet_user():
    user_name = input("Hi there! What's your name? ")
    print(f"Hello, {user_name}! My name is {agent_name}. How can I assist you today?")
    return user_name

# Respond to user input
def respond_to_query(user_input, user_name):
    for keyword, response in KEYWORDS_RESPONSES.items():
        if keyword in user_input.lower():
            return f"{response}"
    return random.choice(RANDOM_RESPONSES)

# Save log to file
def log_session(user_name, log):
    with open(f"chat_log_{user_name}.txt", "w") as file:
        for entry in log:
            file.write(f"{entry}\n")

# Simulate random disconnection
def simulate_disconnection():
    if random.random() < 0.05:  # 5% chance of disconnection
        return True
    return False

def main():
    user_name = greet_user()
    chat_log = []
    
    while True:
        user_input = input(f"[{user_name}]: ")
        chat_log.append(f"User: {user_input}")

        if user_input.lower() in ["bye", "quit", "exit"]:
            print(f"Goodbye, {user_name}! It was nice chatting with you.")
            break

        if simulate_disconnection():
            print(f"Oh no, {agent_name} got disconnected! Please try again later.")
            chat_log.append("Agent disconnected unexpectedly.")
            break

        response = respond_to_query(user_input, user_name)
        print(f"[{agent_name}]: {response}")
        chat_log.append(f"Agent: {response}")

    log_session(user_name, chat_log)

if __name__ == "__main__":
    main()
