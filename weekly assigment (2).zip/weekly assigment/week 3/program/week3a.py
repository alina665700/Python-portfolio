name = input("Enter your name: ").strip()
if not name:
    print("Hello, Stranger!")
else:
    print(f"Hello, {name}!")
