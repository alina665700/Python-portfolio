password1 = input("Enter a new password: ")
password2 = input("Confirm your password: ")

if password1 == password2:
    print("Password Set")
else:
    print("Passwords do not match. Try again.")
