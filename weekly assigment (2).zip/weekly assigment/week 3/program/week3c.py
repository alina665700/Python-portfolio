password = input("Enter a new password: ")

if 8 <= len(password) <= 12:
    print("Password Set")
else:
    print("Password must be between 8 and 12 characters long.")
