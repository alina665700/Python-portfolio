BAD_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']

while True:
    password = input("Enter a new password: ")
    
    if password in BAD_PASSWORDS:
        print("This password is too common. Try a different one.")
    elif not (8 <= len(password) <= 12):
        print("Password must be between 8 and 12 characters long.")
    else:
        print("Password Set")
        break
