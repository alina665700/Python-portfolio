import sys

# 1. nl Command Implementation
def nl_command(file_name):
    try:
        with open(file_name, 'r') as file:
            for line_number, line in enumerate(file, start=1):
                print(f"{line_number}: {line}", end='')
    except FileNotFoundError:
        print(f"File not found: {file_name}")

# 2. diff Command Implementation
def diff_command(file1, file2):
    try:
        with open(file1, 'r') as f1, open(file2, 'r') as f2:
            file1_lines = f1.readlines()
            file2_lines = f2.readlines()

        if file1_lines == file2_lines:
            print("The files are the same.")
        else:
            print("The files are different.")
    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")

# 3. grep Command Implementation
def grep_command(pattern, file_name):
    try:
        with open(file_name, 'r') as file:
            for line in file:
                if pattern in line:
                    print(line, end='')
    except FileNotFoundError:
        print(f"File not found: {file_name}")

# 4. wc Command Implementation
def wc_command(file_name):
    try:
        with open(file_name, 'r') as file:
            lines = file.readlines()
            num_lines = len(lines)
            num_words = sum(len(line.split()) for line in lines)
            num_chars = sum(len(line) for line in lines)

        print(f"Lines: {num_lines}, Words: {num_words}, Characters: {num_chars}")
    except FileNotFoundError:
        print(f"File not found: {file_name}")

# 5. spell Command Implementation
def spell_command(file_name, dictionary_file):
    try:
        with open(dictionary_file, 'r') as dict_file:
            valid_words = set(word.strip().lower() for word in dict_file)

        with open(file_name, 'r') as file:
            for line in file:
                words = line.split()
                for word in words:
                    clean_word = ''.join(filter(str.isalnum, word)).lower()
                    if clean_word and clean_word not in valid_words:
                        print(clean_word)
    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")

# Main function to handle command-line arguments
def main():
    if len(sys.argv) < 3:
        print("Usage: python script.py <command> <args>")
        return

    command = sys.argv[1].lower()

    if command == 'nl' and len(sys.argv) == 3:
        nl_command(sys.argv[2])
    elif command == 'diff' and len(sys.argv) == 4:
        diff_command(sys.argv[2], sys.argv[3])
    elif command == 'grep' and len(sys.argv) == 4:
        grep_command(sys.argv[2], sys.argv[3])
    elif command == 'wc' and len(sys.argv) == 3:
        wc_command(sys.argv[2])
    elif command == 'spell' and len(sys.argv) == 4:
        spell_command(sys.argv[2], sys.argv[3])
    else:
        print("Invalid command or arguments.")

if __name__ == "__main__":
    main()
