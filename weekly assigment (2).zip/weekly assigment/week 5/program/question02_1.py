import sys

# Report how many arguments were provided
print(f"Number of arguments: {len(sys.argv) - 1}")
