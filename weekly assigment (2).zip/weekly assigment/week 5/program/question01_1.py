import sys

# Check the platform
print(f"Operating system platform: {sys.platform}")
